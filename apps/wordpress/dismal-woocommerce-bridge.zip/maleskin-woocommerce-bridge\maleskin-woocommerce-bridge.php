<?php
/**
 * Plugin Name: Maleskin WooCommerce Bridge
 * Plugin URI: https://maleskin.com
 * Description: Synchronizes paid WooCommerce orders with the Maleskin backend.
 * Version: 1.0.0
 * Author: Maleskin
 * Author URI: https://maleskin.com
 * Requires Plugins: woocommerce
 * Text Domain: maleskin-woocommerce-bridge
 */

if (! defined('ABSPATH')) {
    exit;
}

define('MALSKN_WC_BRIDGE_VERSION', '1.0.0');
define('MALSKN_WC_BRIDGE_FILE', __FILE__);
define('MALSKN_WC_BRIDGE_DIR', plugin_dir_path(__FILE__));
define('MALSKN_WC_BRIDGE_URL', plugin_dir_url(__FILE__));

require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-settings.php';
require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-api-client.php';
require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-product-meta.php';
require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-order-sync.php';
require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-customer-accounts.php';
require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-customer-import.php';

final class Maleskin_WooCommerce_Bridge
{
    private static ?Maleskin_WooCommerce_Bridge $instance = null;

    public static function instance(): Maleskin_WooCommerce_Bridge
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    private function __construct()
    {
        add_action('plugins_loaded', [$this, 'boot']);
    }

    public function boot(): void
    {
        if (! class_exists('WooCommerce')) {
            add_action('admin_notices', [$this, 'render_missing_woocommerce_notice']);
            return;
        }

        require_once MALSKN_WC_BRIDGE_DIR . 'includes/class-maleskin-bridge-credit-gateway.php';

        Maleskin_Bridge_Settings::register();
        Maleskin_Bridge_Product_Meta::register();
        $api_client = new Maleskin_Bridge_Api_Client();
        Maleskin_Bridge_Order_Sync::register($api_client);
        Maleskin_Bridge_Customer_Accounts::register($api_client);
        Maleskin_Bridge_Customer_Import::register($api_client);
        Maleskin_Bridge_Credit_Gateway::register();
    }

    public function render_missing_woocommerce_notice(): void
    {
        if (! current_user_can('activate_plugins')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html__('Maleskin WooCommerce Bridge requires WooCommerce to be active.', 'maleskin-woocommerce-bridge');
        echo '</p></div>';
    }
}

Maleskin_WooCommerce_Bridge::instance();
