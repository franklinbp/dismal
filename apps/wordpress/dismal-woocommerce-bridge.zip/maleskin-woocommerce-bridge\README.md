# Maleskin WooCommerce Bridge

Plugin de WordPress/WooCommerce para sincronizar ordenes pagadas con el backend de Maleskin en el VPS.

## Incluye

- Configuracion de URL base y API key del backend
- Mapeo de `softwareId` por producto WooCommerce
- Sincronizacion automatica cuando la orden entra en `processing` o `completed`
- Deteccion de clientes distribuidores por rol de WordPress
- Actualizacion del perfil WooCommerce usando los datos de la orden sincronizada
- Importacion inicial de clientes desde Maleskin a WooCommerce
- Enlace de usuarios WooCommerce con `maleskin_user_id`
- Pasarela `Credito Maleskin` para clientes importados con credito disponible
- Prueba de conexion desde `WooCommerce > Maleskin Bridge`
- Proteccion para no reenviar ordenes ya sincronizadas salvo reintento manual
- Reintento manual desde la ficha de la orden
- Trazabilidad por metadatos de la orden

## Instalacion

1. Copia la carpeta `maleskin-woocommerce-bridge` dentro de `wp-content/plugins/`
2. Activa el plugin en WordPress
3. Ve a `WooCommerce > Maleskin Bridge`
4. Configura:
   - `API Base URL`: `https://api.tudominio.com`
   - `Integration Key`: el mismo valor de `integrations.woocommerce.api-key` en el backend
   - `Paid Order Statuses`
   - `Distributor WordPress Roles`
5. Presiona `Probar conexion con Maleskin`
6. En cada producto WooCommerce completa `Maleskin Software ID`
7. Usa la seccion `Importar clientes desde Maleskin` para crear o enlazar clientes existentes antes de abrir el canal
8. Activa la pasarela `Credito Maleskin` en `WooCommerce > Ajustes > Pagos` si venderas a credito

## Metadatos de orden

El plugin guarda:

- `_maleskin_external_order_id`
- `_maleskin_sale_id`
- `_maleskin_sync_status`
- `_maleskin_sync_message`
- `_maleskin_last_sync_at`

## Metadatos de cliente

El importador guarda en WordPress:

- `_maleskin_user_id`
- `_maleskin_customer_type`
- `_maleskin_enabled`
- `_maleskin_has_credit`
- `_maleskin_credit_limit`
- `_maleskin_credit_used`
- `_maleskin_credit_days`
- `_maleskin_last_sync_at`

## Flujo recomendado

1. Configura la integracion y valida una orden de prueba en staging
2. Importa clientes existentes desde `Maleskin`
3. Pide a los clientes entrar con su `email` y clave de `Maleskin`
4. Revisa que las ordenes nuevas lleguen a `Maleskin` con `saleId`
5. Para clientes con credito, valida que el checkout muestre `Credito Maleskin` solo si el credito disponible alcanza el total del carrito

## Recomendacion operativa

Prueba primero en staging con una orden real o sandbox y valida:

1. Creacion de venta
2. Registro de pago
3. Idempotencia al reenviar la misma orden
4. Mapeo correcto de productos y cliente
5. Importacion inicial de clientes sin duplicados por email
6. Compra a credito sin registrar pago inmediato y con AR abierto en `Maleskin`

## Manual tecnico completo

Consulta:

`docs/integrations/MANUAL_TECNICO_WORDPRESS_WOOCOMMERCE_MALESKIN.md`
